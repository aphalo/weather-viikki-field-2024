# This is a master script calling 7 separate scripts
#
# Data are logged only at one time-step, and for those data logged frequently,
# slower time series are created in the scripts.
#
# Values related to the solar position are computed also in this scripts based
# on time and geographic coordinates. Reference evapotranspiration is also
# computed in the script, from weather data, for each minute and averaged or
# accumulated.
#
# Each script saves its output to a file on disk. These files are overwritten
# each time the scripts are run.
#
# To plot daily summaries, the R markdown file 'day-avg-water-et-plots-2024.Rmd'
# can be rendered.

# ---
# R code is extracted from the R markdown files used to read the raw data,
# only when needed (R file missing or out-of-date compared to Rmd file).

# The scripts expect the files with raw data from the logger to be in folder
# "data-latest" within the current folder!!

# Loading and processing the data logged at 0.5 s intervals takes several
# minutes in a reasonably fast PC. Data are about 1 GB per month. R may use
# something like 4 GB RAM for a file this large. (I will need to think a strategy
# for handling this as the data set will keep growing).

library(knitr)


  # if (!file.exists("read-millisecond-data-2024.R") ||
  #     file.mtime("read-millisecond-data-2024.Rmd") >
  #     file.mtime("read-millisecond-data-2024.R")) {
  #   purl("read-millisecond-data-2024.Rmd")
  # }
  # message("Reading 50 milliseconds frequency data")
  # source("read-millisecond-data-2024.R")
  # message("Processing 1/2 second frequency data")
  # source("merge-second-data-2024.R")


if (!file.exists("read-second-data-2024.R") ||
                 file.mtime("read-second-data-2024.Rmd") >
                 file.mtime("read-second-data-2024.R")) {
  purl("read-second-data-2024.Rmd")
}
message("Reading 1/2 second frequency data")
source("read-second-data-2024.R")
message("Processing 1/2 second frequency data")
source("merge-second-data-2024.R")

if (!file.exists("read-minute-data-2024.R") ||
                 file.mtime("read-minute-data-2024.Rmd") >
                 file.mtime("read-minute-data-2024.R")) {
  purl("read-minute-data-2024.Rmd")
}
message("Reading 1 minute frequency data")
source("read-minute-data-2024.R")
message("Processing 1 minute frequency data")
source("merge-minute-data-2024.R")

if (!file.exists("read-hour-data-2024.R") ||
    file.mtime("read-hour-data-2024.Rmd") >
    file.mtime("read-hour-data-2024.R")) {
  purl("read-hour-data-2024.Rmd")
}
message("Reading 1 hour frequency data")
source("read-hour-data-2024.R")
message("Processing 1 hour frequency data")
source("merge-hour-data-2024.R")

message("Processing 1 day frequency data")
source("merge-day-data-2024.R")

message("Done!")

files <- list.files("data-rda", ".*2024_latest\\.tb\\.rda", full.names = TRUE)
file.info(files)

